"""Read-only validation of the essential manuscript data package."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, log_loss

def check(root):
    root = Path(root).resolve()
    manifest = json.loads((root/'MANIFEST.json').read_text())
    for f in manifest['files']:
        p = root/f['path']
        assert p.stat().st_size == f['bytes'], f['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest() == f['sha256'], f['path']
    read = lambda name: pd.read_csv(root/name)
    load = lambda name: json.loads((root/name).read_text())
    def close(a, b):
        np.testing.assert_allclose(a, b, rtol=0, atol=1e-10)
    def same_ids(a, b):
        assert not a.ID.duplicated().any() and not b.ID.duplicated().any()
        assert set(a.ID) == set(b.ID)
    def grouped(f):
        assert set(f.validation_fold) == {1,2,3,4,5}
        for ns in ['patient_id', 'brats_patient_id', 'validation_group']:
            assert f.groupby(ns).validation_fold.nunique().eq(1).all(), ns
    def metrics(frame, names, saved):
        y = frame.tumor_label.to_numpy()
        for name in names:
            p = frame[name+'_oof_probability'].to_numpy()
            assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
            actual = dict(roc_auc=roc_auc_score(y,p),
                          ap_treatment_change=average_precision_score(1-y,1-p),
                          brier=brier_score_loss(y,p), log_loss=log_loss(y,p))
            for k,v in actual.items(): close(v,saved[name][k])
            predicted = p>=0.5
            for k,v in dict(tp=((y==1)&predicted).sum(),tn=((y==0)&~predicted).sum(),
                            fp=((y==0)&predicted).sum(),fn=((y==1)&~predicted).sum()).items():
                assert int(v)==saved[name][k], (name,k)
    def intervals(frame, saved):
        assert len(frame)==2000 and frame.draw.nunique()==2000
        for name,v in saved.items():
            close(np.percentile(frame[name],[2.5,97.5]),[v['lower'],v['upper']])

    # Reconstruct labels and clinical inputs from the two original workbooks.
    sys.path.insert(0,str(root/'src'))
    from rn_public.ucsd_clinical_revalidation import prepare_cohort
    clinical, excluded = prepare_cohort(root)
    frozen = read('data/processed/ucsd_clinical_revalidated_cohort.csv')
    for d in [clinical, frozen]: d['initial_event_offset_raw']=d.initial_event_offset_raw.astype(str)
    pd.testing.assert_frame_equal(clinical,frozen)
    assert len(excluded)==5
    d = read('data/processed/ucsd_clinical_image_features.csv')
    assert (len(d), d.patient_id.nunique(), d.validation_group.nunique(), int(d.tumor_label.sum()))==(182,135,135,141)
    d['initial_event_offset_raw']=d.initial_event_offset_raw.astype(str)
    pd.testing.assert_frame_equal(d[clinical.columns],clinical[clinical.ID.isin(d.ID)].reset_index(drop=True))
    lock = load('reports/ucsd_fusion/analysis_lock.json')
    for p,digest in lock['input_sha256'].items(): assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest
    for fn in ['ucsd_image_features.csv','ucsd_image_features_eroded.csv']:
        f = read('data/processed/'+fn); same_ids(d,f)
        assert np.isfinite(f[lock['model_features']['MRI']].to_numpy()).all()
    original = read('data/processed/ucsd_image_features.csv')
    pd.testing.assert_frame_equal(d[['ID',*lock['model_features']['MRI']]],original)
    assert d.initial_event_missing.sum()==36
    assert d.initial_event_missing.eq(d.log_initial_event_days.isna().astype(int)).all()
    pred = read('data/processed/ucsd_fusion_oof.csv')
    fold = read('reports/ucsd_fusion/cohort_and_fold_manifest.csv')
    same_ids(d,pred); grouped(pred)
    pd.testing.assert_frame_equal(pred[fold.columns],fold)
    close(d.tumor_label,pred.tumor_label)
    main = load('reports/ucsd_fusion/metrics.json')
    metrics(pred,['M0','M1','MRI','Fusion','MRI_eroded','Fusion_eroded'],main['metrics'])
    boot = read('reports/ucsd_fusion/paired_patient_bootstrap.csv')
    intervals(boot,main['patient_cluster_bootstrap_95ci'])
    single = read('data/processed/ucsd_stability_single_scan_oof.csv')
    stability = load('reports/ucsd_stability/metrics.json')
    assert (len(single),single.patient_id.nunique(),int(single.tumor_label.sum()))==(135,135,113)
    selection = read('reports/ucsd_stability/single_scan_selection.csv')
    assert set(single.ID)==set(selection.loc[selection.selected,'ID'])
    grouped(single); metrics(single,['M0','M1','MRI','Fusion'],stability['single_scan']['metrics'])
    intervals(read('reports/ucsd_stability/single_scan_patient_bootstrap.csv'),stability['single_scan']['bootstrap_95ci'])
    repeated = read('data/processed/ucsd_stability_repeated_oof.csv')
    repeated_metrics = read('reports/ucsd_stability/repeated_metrics.csv')
    assert repeated.repeat.nunique()==20 and len(repeated)==3640
    for n,g in repeated.groupby('repeat'):
        same_ids(d,g);grouped(g)
        saved = repeated_metrics[repeated_metrics.repeat.eq(n)].set_index('model').to_dict('index')
        metrics(g,['M0','M1','MRI','Fusion'],saved)
    first=repeated[repeated.repeat.eq(1)].set_index('ID').sort_index()
    for model in ['M0','M1','MRI','Fusion']:
        close(first[model+'_oof_probability'],pred.set_index('ID').sort_index()[model+'_oof_probability'])
    sources = read('reports/ucsd_batch_features/source_manifest.csv')
    qc = read('reports/ucsd_batch_features/actual_file_QC.csv')
    assert len(sources)==546 and not sources.duplicated(['ID','sequence']).any()
    assert set(sources.ID)==set(d.ID) and sources.groupby('ID').size().eq(3).all()
    assert sources.sha256.str.fullmatch('[0-9a-f]{64}').all()
    pd.testing.assert_frame_equal(sources[['ID','sequence','bytes','sha256']].sort_values(['ID','sequence']).reset_index(drop=True),
                                  qc[['ID','sequence','bytes','sha256']].sort_values(['ID','sequence']).reset_index(drop=True))
    return dict(status='PASS',source_commit=manifest['source_commit'],files_verified=len(manifest['files']),
                raw_clinical_scans=243,clinical_scans=238,primary_scans=182,primary_patients=135,
                tumor_scans=141,treatment_change_scans=41,missing_interval_scans=36,
                primary_auc=main['metrics']['Fusion']['roc_auc'],clinical_auc=main['metrics']['M1']['roc_auc'],
                paired_auc_increment=main['metrics']['Fusion']['roc_auc']-main['metrics']['M1']['roc_auc'],
                repeated_partitions=20,single_scan_patients=135,referenced_image_files=546,
                model_fits_performed=0,image_downloads_performed=0)

if __name__=='__main__':
    print(json.dumps(check(Path(__file__).parent),indent=2))
