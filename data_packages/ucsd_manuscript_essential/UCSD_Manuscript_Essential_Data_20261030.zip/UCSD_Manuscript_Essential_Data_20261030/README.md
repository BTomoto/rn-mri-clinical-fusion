# 论文必要数据包 / Essential manuscript data

对应论文：Clinical-MRI Feature Fusion for Distinguishing Residual or Recurrent Tumor from Treatment-Related Changes after Glioma Treatment: A Public-Data Internal Validation Study。

版本：2026-10-30；对应 Revision 1。原始文件快照固定在 GitHub 提交 `73f04f53c42257a7c45a64aaa96066d8dc61660f`。

## 从哪里开始

主要分析表是 `data/processed/ucsd_clinical_image_features.csv`：182次检查、135名患者，含标签、临床输入和8个MRI特征。`tumor_label=1` 为残留或复发肿瘤，`0` 为治疗相关改变。原始临床资料和派生数据分开保留，CSV采用UTF-8，检查编号和患者编号均沿用公开数据集中的编号。

| 内容 | 路径 | 用途 |
| --- | --- | --- |
| 原始临床工作簿 | `data/raw/reference/ucsd_ptgbm_clinical_v3.xlsx` | 原始243次检查、178名患者；含来源数据字典 |
| 原始治疗相关改变病例清单 | `data/raw/reference/ucsd_ptgbm_negative_cases.xlsx` | 核对51次治疗相关改变检查及来源诊断文字 |
| 镜像参与者元数据 | `data/raw/reference/ucsd_mirror_participants.tsv` | 核对临床与影像编号的对应关系 |
| 全部原始临床字段导出 | `data/processed/ucsd_clinical_all_fields_raw.csv` | 243行、36字段，便于程序读取；这是工作簿的导出表 |
| 临床分析队列 | `data/processed/ucsd_clinical_revalidated_cohort.csv` | 238次检查、176名患者，支持纳入流程和临床覆盖表 |
| 主模型输入 | `data/processed/ucsd_clinical_image_features.csv` | 182次检查、135名患者，141次肿瘤、41次治疗相关改变 |
| MRI特征及边界分析特征 | `data/processed/ucsd_image_features*.csv` | 8个MRI特征的原始提取数值和边界分析数值；属于派生数据 |
| 主分析预测 | `data/processed/ucsd_fusion_oof.csv` | 各模型逐检查折外肿瘤概率、标签、折号和0.5阈值分类 |
| 补充分析预测 | `data/processed/ucsd_stability_*_oof.csv` | 20次分组划分和135次单检查分析 |
| 分组划分、锁定配置和结果 | `reports/ucsd_fusion/`、`reports/ucsd_stability/` | 核对AUC、AP、校准、误差和已保存的bootstrap区间 |
| 纳入与影像文件清单 | `reports/ucsd_batch_features/` | 238次检查的覆盖状态、546个影像文件的地址与哈希、已记录质控 |
| 字段解释 | `DATA_DICTIONARY.csv`、`reports/ucsd_batch_features/feature_dictionary.csv` | 临床编码、标签、概率及MRI特征定义 |
| 核验程序 | `verify_package.py`、`Verify_Essential_Data.ipynb` | 验证完整性、患者分组及关键论文结果 |
| 原分析代码快照 | `src/rn_public/` 和3个protocol文件 | 保存当前数据生成与分析规则；完整研究notebook仍在仓库 `notebooks/18...`、`19...` 和 `20...` |

## 数据范围

本包保留必要的表格级来源数据、MRI特征、分组信息和已保存结果。MRI体素图像及分割文件没有装入压缩包。使用本包可以从原始临床工作簿重建临床变量，并用已提取MRI特征进行模型分析，也可以直接重算折外预测的指标。若要从图像重新提取MRI特征，使用 `reports/ucsd_batch_features/source_manifest.csv` 中546条记录获取对应FLAIR、T1post和BraTS分割文件；该清单同时保存文件地址、字节数和SHA256。包内MRI特征不能替代体素图像进行重新提取。

完整来源临床表只有约0.1 MB，因此保留原工作簿和51例来源清单有助于核对排除记录及纳入流程。公开源表包含的其他字段不会自动进入模型；实际模型变量由 `reports/ucsd_fusion/analysis_lock.json` 确定。标识字段只用于连接及分组。

## 快速核验

解压后进入本目录，使用原分析环境中的Python，或在新环境安装 `requirements_verify.txt` 后运行：

```bash
python verify_package.py
```

也可在Jupyter中打开 `Verify_Essential_Data.ipynb` 并运行全部单元。核验程序读取现有结果、重建临床输入和重新计算指标，不会拟合模型、下载MRI或覆盖原始文件。它检查所有包内文件的SHA256、来源工作簿、临床映射、182次主分析检查、135次单检查、20次重复划分、患者分组和bootstrap百分位区间。

模型拟合及完整图表的notebook：
- https://github.com/BTomoto/rn-mri-clinical-fusion/blob/73f04f53c42257a7c45a64aaa96066d8dc61660f/notebooks/18_ucsd_clinical_mri_fusion.ipynb
- https://github.com/BTomoto/rn-mri-clinical-fusion/blob/73f04f53c42257a7c45a64aaa96066d8dc61660f/notebooks/19_ucsd_model_stability.ipynb
- https://github.com/BTomoto/rn-mri-clinical-fusion/blob/73f04f53c42257a7c45a64aaa96066d8dc61660f/notebooks/20_ucsd_paper_tables_and_figures.ipynb

原分析的完整环境见 `requirements.txt`。重新拟合请使用仓库的完整环境与相应notebook，并另存输出；当前包保持论文结果的固定快照。

## 来源、署名与文件校验

来源：公开UCSD-PTGBM集合，https://www.cancerimagingarchive.net/collection/ucsd-ptgbm/ 。描述论文：Gagnon等，https://doi.org/10.1038/s41597-025-06499-z 。原临床工作簿的来源记录列明CC BY 4.0；来源链接和原始哈希见 `data/metadata/public_label_audit_20261029/downloaded_sources.json`。镜像文件记录见相应清单，数据来源及许可说明见 `DATA_LICENSES.md`。本包没有加入其他研究队列。

`MANIFEST.json` 逐文件记录字节数、SHA256、来源仓库路径、Git blob SHA及数据角色。来源文件均逐字节复制；本次新增内容只有打包说明、字段说明、核验代码和manifest。概率、标签、特征、模型配置及已有统计结果均沿用固定版本。

English note: This compact package contains original public clinical workbooks and derived analysis tables for the Revision 1 manuscript. MRI voxel data are referenced through a 546-file manifest rather than bundled. All source payloads are byte-identical to the pinned repository commit. Run `python verify_package.py` to verify hashes, cohort membership, patient-grouped partitions, clinical reconstruction and saved prediction-based results. No models are fitted by this check.
